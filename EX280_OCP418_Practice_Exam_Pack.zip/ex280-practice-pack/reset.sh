#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

for p in area51 math czech apples path-finder database checker marathon charts-development; do
  oc delete project "$p" --ignore-not-found --wait=true || true
done

"$ROOT/setup.sh"
