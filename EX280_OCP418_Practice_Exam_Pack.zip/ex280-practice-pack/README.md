# EX280 Practice Pack

Built from the 16-question EX280/OCP 4.18 practice set you shared.

Important source inconsistencies handled explicitly:
- Q6 question says `decoder_Ring`; the source answer shows `decoder_ring`. This pack uses the QUESTION value `decoder_Ring`.
- Q9 asks for `ex-280-sa`; the source answer grants SCC to `ex280sa`. This pack uses `ex-280-sa`.
- Q12 question says namespace label `team=devsecops`; the sample answer uses a different label. This pack grades `team=devsecops`.
- Q12 NetworkPolicy belongs in `database`; the source note saying to run it in `checker` is treated as a typo.
- Q15/Q16 numbering in the source outline is inconsistent; this pack follows the detailed order: Q15 Helm, Q16 bootstrap project template.

Files:
- `setup.sh` prepares broken/starting scenarios.
- `grade.sh` grades all 16 questions.
- `reset.sh` recreates namespaced scenarios.
- `SOLUTION-KEY.md` is for instructor use.
- `apps/` contains helper manifests.

Run:
    chmod +x setup.sh grade.sh reset.sh
    ./setup.sh
    ./grade.sh
    ./reset.sh

`setup.sh` is conservative with OAuth/kubeadmin and other cluster-wide state. Q1-Q4, Q13 and Q16 are graded from actual cluster state but are not destructively reset by default.
