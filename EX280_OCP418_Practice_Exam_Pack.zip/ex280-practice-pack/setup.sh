#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

need(){ command -v "$1" >/dev/null 2>&1 || { echo "Missing command: $1"; exit 1; }; }
need oc

mkproj(){
  oc get project "$1" >/dev/null 2>&1 || oc new-project "$1" >/dev/null
}

for p in area51 math czech apples path-finder database checker marathon charts-development; do
  mkproj "$p"
done

oc apply -f "$ROOT/apps/oxcart.yaml"
oc delete secret magic -n math --ignore-not-found
oc apply -f "$ROOT/apps/qed.yaml"

oc delete configmap ex280-cm -n czech --ignore-not-found
oc apply -f "$ROOT/apps/ernie.yaml"

oc delete sa ex-280-sa -n apples --ignore-not-found
oc apply -f "$ROOT/apps/oranges.yaml"

oc apply -f "$ROOT/apps/voyager.yaml"

oc label ns checker team=devsecops --overwrite
oc label ns database team=database --overwrite
oc delete networkpolicy db-allow-mysql-comm -n database --ignore-not-found
oc apply -f "$ROOT/apps/network-lab.yaml"

oc delete cronjob scaling -n marathon --ignore-not-found
oc delete sa ex280-ocpsa -n marathon --ignore-not-found

echo
echo "EX280 practice environment prepared."
echo "Q1-Q4, Q13 and Q16 are cluster-scoped and are not destructively reset."
echo "Use ./grade.sh after completing the questions."
