# Instructor Solution Key

Q6:
    oc project math
    oc create secret generic magic --from-literal=decoder_Ring=000VRCKukQdrosbclOc2ZYhDk

Q7:
    oc set env deployment/qed --from=secret/magic

Q8:
    oc project czech
    oc create configmap ex280-cm --from-literal=RESPONSE='six czech cricket critics'
    oc set env deployment/ernie --from=configmap/ex280-cm

Q9:
    oc project apples
    oc create sa ex-280-sa
    oc adm policy add-scc-to-user anyuid -z ex-280-sa -n apples

Q10:
    oc set serviceaccount deployment/oranges ex-280-sa
    oc patch service oranges -p '{"spec":{"selector":{"app":"oranges"}}}'

Q11:
    oc set resources deployment/voyager -n path-finder --requests=memory=80Mi --limits=memory=80Mi

Q12:
    apiVersion: networking.k8s.io/v1
    kind: NetworkPolicy
    metadata:
      name: db-allow-mysql-comm
      namespace: database
    spec:
      podSelector:
        matchLabels:
          network.openshift.io/policy-group: database
      policyTypes:
      - Ingress
      ingress:
      - from:
        - namespaceSelector:
            matchLabels:
              team: devsecops
          podSelector:
            matchLabels:
              deployment: web-mysql
        ports:
        - protocol: TCP
          port: 3304

Q14:
    oc project marathon
    oc create sa ex280-ocpsa
    oc adm policy add-cluster-role-to-user cluster-admin -z ex280-ocpsa -n marathon
    oc create cronjob scaling --image=quay.io/redhattraining/scaling --schedule='5 4 2 * *'
    oc patch cronjob scaling -p '{"spec":{"successfulJobsHistoryLimit":13,"jobTemplate":{"spec":{"template":{"spec":{"serviceAccountName":"ex280-ocpsa"}}}}}}'

Q15:
    helm repo add ex280-repo http://helm.ocp4.example.com/charts
    helm repo update
    helm search repo ex280-repo/etherpad --versions
    # Inspect chart values and set route host:
    # etherpad-charts-development.apps.ocp4.example.com

Q16:
    oc adm create-bootstrap-project-template -o yaml > project-request.yaml
    # Add ${PROJECT_NAME}-limitrange and ${PROJECT_NAME}-quota objects with the values from the question.
    # Create the template in openshift-config and configure:
    # project.config.openshift.io/cluster.spec.projectRequestTemplate.name
