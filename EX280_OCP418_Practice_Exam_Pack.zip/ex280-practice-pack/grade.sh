#!/usr/bin/env bash
set -u

PASS=0
FAIL=0
PTS=18.75
SCORE=0

passq(){ printf "Q%-2s PASS - %s\n" "$1" "$2"; PASS=$((PASS+1)); SCORE=$(awk -v s="$SCORE" -v p="$PTS" 'BEGIN{printf "%.2f",s+p}'); }
failq(){ printf "Q%-2s FAIL - %s\n" "$1" "$2"; FAIL=$((FAIL+1)); }
j(){ oc "$@" 2>/dev/null; }

# Q1
idp=$(j get oauth cluster -o jsonpath='{range .spec.identityProviders[*]}{.name}{"|"}{.type}{"|"}{.htpasswd.fileData.name}{"\n"}{end}' | grep '^htpass-ex280|HTPasswd|htpass-idp-ex280$' || true)
if [[ -n "$idp" ]] && j get secret htpass-idp-ex280 -n openshift-config >/dev/null; then
  passq 1 "HTPasswd IDP configured"
else
  failq 1 "htpass-ex280 / htpass-idp-ex280 not found"
fi

# Q2
a=$(oc auth can-i '*' '*' --as=jobs 2>/dev/null || true)
b=$(oc auth can-i create projectrequests.project.openshift.io --as=wozniak 2>/dev/null || true)
c=$(oc auth can-i create projectrequests.project.openshift.io --as=armstrong 2>/dev/null || true)
d=$(oc auth can-i '*' '*' --as=wozniak 2>/dev/null || true)
k=$(j get secret kubeadmin -n kube-system -o name || true)
if [[ "$a" == yes && "$b" == yes && "$c" == no && "$d" == no && -z "$k" ]]; then
  passq 2 "cluster permissions correct"
else
  failq 2 "jobs=$a wozniak-project=$b armstrong-project=$c wozniak-admin=$d kubeadmin=${k:-absent}"
fi

# Q3
ok=1
for p in apollo titan gemini bluebook apache; do j get project "$p" >/dev/null || ok=0; done
[[ "$(oc auth can-i update deployments -n apollo --as=armstrong 2>/dev/null)" == yes ]] || ok=0
[[ "$(oc auth can-i update deployments -n titan --as=armstrong 2>/dev/null)" == yes ]] || ok=0
[[ "$(oc auth can-i get pods -n apollo --as=collins 2>/dev/null)" == yes ]] || ok=0
[[ "$ok" == 1 ]] && passq 3 "projects and project RBAC correct" || failq 3 "project/RBAC checks failed"

# Q4
ok=1
j get group commander -o jsonpath='{.users[*]}' | grep -qw wozniak || ok=0
j get group pilot -o jsonpath='{.users[*]}' | grep -qw adlerin || ok=0
[[ "$(oc auth can-i update deployments -n apache --as=wozniak 2>/dev/null)" == yes ]] || ok=0
[[ "$(oc auth can-i update deployments -n gemini --as=wozniak 2>/dev/null)" == yes ]] || ok=0
[[ "$(oc auth can-i get pods -n apache --as=adlerin 2>/dev/null)" == yes ]] || ok=0
[[ "$(oc auth can-i update deployments -n apache --as=adlerin 2>/dev/null)" == no ]] || ok=0
[[ "$ok" == 1 ]] && passq 4 "groups and permissions correct" || failq 4 "group checks failed"

# Q5
term=$(j get route oxcart -n area51 -o jsonpath='{.spec.tls.termination}' || true)
host=$(j get route oxcart -n area51 -o jsonpath='{.spec.host}' || true)
cert=$(j get route oxcart -n area51 -o jsonpath='{.spec.tls.certificate}' || true)
key=$(j get route oxcart -n area51 -o jsonpath='{.spec.tls.key}' || true)
[[ "$term" == edge && "$host" == oxcart.apps.ocp4.example.com && -n "$cert" && -n "$key" ]] \
  && passq 5 "secure edge route configured" || failq 5 "edge TLS route incomplete"

# Q6
raw=$(j get secret magic -n math -o jsonpath='{.data.decoder_Ring}' || true)
val=""; [[ -n "$raw" ]] && val=$(printf %s "$raw" | base64 -d 2>/dev/null || true)
[[ "$val" == "000VRCKukQdrosbclOc2ZYhDk" ]] \
  && passq 6 "magic secret correct" || failq 6 "magic/decoder_Ring missing or incorrect"

# Q7
ref=$(j get deploy qed -n math -o jsonpath='{range .spec.template.spec.containers[*].env[*]}{.name}{"="}{.valueFrom.secretKeyRef.name}{":"}{.valueFrom.secretKeyRef.key}{"\n"}{end}' || true)
host=$(j get route qed -n math -o jsonpath='{.spec.host}' || true)
out=""; [[ -n "$host" ]] && out=$(curl -fsS --max-time 5 "http://$host" 2>/dev/null || true)
if echo "$ref" | grep -q 'decoder_Ring=magic:decoder_Ring' && echo "$out" | grep -q 'Application configured correctly'; then
  passq 7 "qed consumes magic"
else
  failq 7 "qed secret reference/output incorrect"
fi

# Q8
cm=$(j get cm ex280-cm -n czech -o jsonpath='{.data.RESPONSE}' || true)
ref=$(j get deploy ernie -n czech -o jsonpath='{range .spec.template.spec.containers[*].env[*]}{.name}{"="}{.valueFrom.configMapKeyRef.name}{":"}{.valueFrom.configMapKeyRef.key}{"\n"}{end}' || true)
host=$(j get route ernie -n czech -o jsonpath='{.spec.host}' || true)
out=""; [[ -n "$host" ]] && out=$(curl -fsS --max-time 5 "http://$host" 2>/dev/null || true)
if [[ "$cm" == "six czech cricket critics" ]] && echo "$ref" | grep -q 'RESPONSE=ex280-cm:RESPONSE' && echo "$out" | grep -q 'six czech cricket critics'; then
  passq 8 "ConfigMap injection works"
else
  failq 8 "ConfigMap/RESPONSE/output incorrect"
fi

# Q9
sa=$(j get sa ex-280-sa -n apples -o name || true)
who=$(oc adm policy who-can use scc/anyuid 2>/dev/null || true)
if [[ -n "$sa" ]] && echo "$who" | grep -q 'system:serviceaccount:apples:ex-280-sa'; then
  passq 9 "ex-280-sa exists and can use anyuid"
else
  failq 9 "service account or anyuid permission missing"
fi

# Q10
saused=$(j get deploy oranges -n apples -o jsonpath='{.spec.template.spec.serviceAccountName}' || true)
sel=$(j get svc oranges -n apples -o jsonpath='{.spec.selector.app}' || true)
ep=$(j get endpoints oranges -n apples -o jsonpath='{.subsets[0].addresses[0].ip}' || true)
host=$(j get route oranges -n apples -o jsonpath='{.spec.host}' || true)
out=""; [[ -n "$host" ]] && out=$(curl -fsS --max-time 5 "http://$host" 2>/dev/null || true)
if [[ "$saused" == ex-280-sa && "$sel" == oranges && -n "$ep" ]] && echo "$out" | grep -q 'ORANGES application is running'; then
  passq 10 "oranges fixed and exposed"
else
  failq 10 "service account/selector/endpoint/output incorrect"
fi

# Q11
mem=$(j get deploy voyager -n path-finder -o jsonpath='{.spec.template.spec.containers[0].resources.requests.memory}' || true)
ready=$(j get deploy voyager -n path-finder -o jsonpath='{.status.readyReplicas}' || echo 0)
if [[ "$mem" != 80Gi && "${ready:-0}" -ge 1 ]]; then passq 11 "voyager resources corrected"; else failq 11 "voyager memory=$mem ready=${ready:-0}"; fi

# Q12
np=$(j get netpol db-allow-mysql-comm -n database -o yaml || true)
ok=1
echo "$np" | grep -q 'network.openshift.io/policy-group: database' || ok=0
echo "$np" | grep -q 'team: devsecops' || ok=0
echo "$np" | grep -q 'deployment: web-mysql' || ok=0
echo "$np" | grep -q 'port: 3304' || ok=0
cpod=$(j get pod -n checker -l deployment=web-mysql -o jsonpath='{.items[0].metadata.name}' || true)
logs=""; [[ -n "$cpod" ]] && logs=$(j logs "$cpod" -n checker --tail=20 || true)
echo "$logs" | grep -q 'Connection Successful' || ok=0
[[ "$ok" == 1 ]] && passq 12 "NetworkPolicy works" || failq 12 "policy/connectivity check failed"

# Q13
sub=$(j get subscriptions.operators.coreos.com -A -o jsonpath='{range .items[*]}{.metadata.name}{"|"}{.spec.channel}{"|"}{.spec.installPlanApproval}{"\n"}{end}' | grep -Ei 'file.*integrity.*\|stable\|Automatic' | head -1 || true)
csv=$(j get csv -A -o jsonpath='{range .items[*]}{.metadata.name}{"|"}{.status.phase}{"\n"}{end}' | grep -Ei 'file.*integrity.*\|Succeeded' | head -1 || true)
[[ -n "$sub" && -n "$csv" ]] && passq 13 "File Integrity Operator installed" || failq 13 "stable/Automatic subscription or Succeeded CSV not found"

# Q14
sched=$(j get cronjob scaling -n marathon -o jsonpath='{.spec.schedule}' || true)
hist=$(j get cronjob scaling -n marathon -o jsonpath='{.spec.successfulJobsHistoryLimit}' || true)
sa=$(j get cronjob scaling -n marathon -o jsonpath='{.spec.jobTemplate.spec.template.spec.serviceAccountName}' || true)
img=$(j get cronjob scaling -n marathon -o jsonpath='{.spec.jobTemplate.spec.template.spec.containers[0].image}' || true)
adm=$(oc auth can-i '*' '*' --as=system:serviceaccount:marathon:ex280-ocpsa 2>/dev/null || true)
[[ "$sched" == '5 4 2 * *' && "$hist" == 13 && "$sa" == ex280-ocpsa && "$img" == quay.io/redhattraining/scaling && "$adm" == yes ]] \
  && passq 14 "CronJob correct" || failq 14 "schedule/history/SA/image/RBAC incorrect"

# Q15
route=$(j get route -n charts-development -o jsonpath='{range .items[*]}{.spec.host}{"\n"}{end}' | grep '^etherpad-charts-development.apps.ocp4.example.com$' || true)
rel=""
command -v helm >/dev/null 2>&1 && rel=$(helm list -n charts-development -q 2>/dev/null || true)
[[ -n "$route" && -n "$rel" ]] && passq 15 "Helm app and route found" || failq 15 "Helm release or required route missing"

# Q16
tmpl=$(j get project.config.openshift.io/cluster -o jsonpath='{.spec.projectRequestTemplate.name}' || true)
tjson=""; [[ -n "$tmpl" ]] && tjson=$(j get template "$tmpl" -n openshift-config -o yaml || true)
ok=1
for pat in 'pods: "10"' 'requests.memory: 1Gi' 'requests.cpu: "2"' 'limits.memory: 4Gi' 'limits.cpu: "4"' 'cpu: 30m' 'memory: 30Mi' 'cpu: 100m' 'memory: 100Mi'; do
  echo "$tjson" | grep -Fq "$pat" || ok=0
done
[[ -n "$tmpl" && "$ok" == 1 ]] && passq 16 "project request template found with quota/limits" || failq 16 "project template incomplete"

echo
echo "PASS=$PASS FAIL=$FAIL SCORE=$SCORE/300"
awk -v s="$SCORE" 'BEGIN{print (s>=210 ? "RESULT=PASS" : "RESULT=NOT YET PASSING")}'
